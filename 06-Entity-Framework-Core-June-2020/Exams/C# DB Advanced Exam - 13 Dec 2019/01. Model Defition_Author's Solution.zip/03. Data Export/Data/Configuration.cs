﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-F0IMF0D\SQLEXPRESS;Database=BookShop;Trusted_Connection=True";
    }
}