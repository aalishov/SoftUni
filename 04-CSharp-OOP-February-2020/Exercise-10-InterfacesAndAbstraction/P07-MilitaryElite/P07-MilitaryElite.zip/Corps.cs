﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07_MilitaryElite
{
    public enum Corps
    {
        Airforces = 0,
        Marines=1
    }
}
