﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05_BirthdayCelebrations
{
  public  class Robot:Inhabitant
    {
        public string Model { get; set; }
    }
}
