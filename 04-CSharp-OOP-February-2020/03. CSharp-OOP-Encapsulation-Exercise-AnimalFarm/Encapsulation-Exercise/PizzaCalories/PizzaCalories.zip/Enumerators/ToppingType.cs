﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PizzaCalories.Enumerators
{
    public enum ToppingType
    {
       
        meat = 0,
        veggies = 1,
        cheese = 2,
        sauce = 3
    }
}
