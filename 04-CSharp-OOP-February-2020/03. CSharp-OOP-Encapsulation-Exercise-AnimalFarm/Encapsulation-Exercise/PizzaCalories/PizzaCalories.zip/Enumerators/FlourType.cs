﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PizzaCalories.Enumerators
{
    public enum FlourType
    {

        white = 0,
        wholegrain = 1
    }

}
