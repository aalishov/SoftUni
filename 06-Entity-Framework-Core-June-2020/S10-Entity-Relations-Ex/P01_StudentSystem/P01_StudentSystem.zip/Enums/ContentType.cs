﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Enums
{
    public enum ContentType
    {
        Application,
        Pdf,
        Zip
    }
}
