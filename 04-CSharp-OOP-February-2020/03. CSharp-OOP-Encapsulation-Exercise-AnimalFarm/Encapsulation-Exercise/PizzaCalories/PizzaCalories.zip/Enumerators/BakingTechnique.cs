﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PizzaCalories.Enumerators
{
    public enum BakingTechnique
    {
         
        crispy=0,
        chewy=1,
        homemade=2
    }
}
