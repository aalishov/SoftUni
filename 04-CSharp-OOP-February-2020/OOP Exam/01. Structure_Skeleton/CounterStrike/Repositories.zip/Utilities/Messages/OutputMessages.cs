﻿namespace CounterStrike.Utilities.Messages
{

    public static class OutputMessages
    {
        //Used
        public const string SuccessfullyAddedPlayer = "Successfully added player {0}.";
        //Used
        public const string SuccessfullyAddedGun = "Successfully added gun {0}.";
    }
}
