﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_RawData.Enumerator
{
    public enum CargoType
    {
        fragile = 0,
        flamable = 1
    }
}
