﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04_BorderControl
{
    public class Citizen : Inhabitant
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
