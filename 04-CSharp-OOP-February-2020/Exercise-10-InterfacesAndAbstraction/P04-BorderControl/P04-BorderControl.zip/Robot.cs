﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04_BorderControl
{
  public  class Robot:Inhabitant
    {
        public string Model { get; set; }
    }
}
